package com.crossover.trial.weather;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Basic airport information.
 *
 * @author code test administrator
 */
public class AirportData {

    // CR: Should be private
    /** the three letter IATA code */
    String iata;

    // CR: Should be private
    /** latitude value in degrees */
    double latitude;

    // CR: Should be private
    /** longitude value in degrees */
    double longitude;

    public AirportData() { }

    public String getIata() {
        return iata;
    }

    // CR: iata is in equals, should be immutable, move set to constructor
    public void setIata(String iata) {
        this.iata = iata;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public String toString() {
        return ReflectionToStringBuilder.toString(this, ToStringStyle.NO_CLASS_NAME_STYLE);
    }

    // CR: Strange equals
    // CR: NPE if iata == null    // CR: hashCode() should be overriden, otherwise say hi to hashmap magic
    public boolean equals(Object other) {
        if (other instanceof AirportData) {
            return ((AirportData)other).getIata().equals(this.getIata());
        }

        return false;
    }
}
